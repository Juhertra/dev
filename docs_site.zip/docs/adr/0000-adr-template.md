# ADR-0000: <Title>
## Status
Proposed | Accepted | Superseded
## Context
## Decision
## Consequences
## Alternatives Considered
## Links
